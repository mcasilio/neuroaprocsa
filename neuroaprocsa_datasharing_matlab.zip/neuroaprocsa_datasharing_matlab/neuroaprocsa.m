%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Code for reproducing analyses of Casilio et al., "Four dimensions of
% naturalistic language production in aphasia after stroke"

% Last updated by Marianne Casilio on 4/25/24
% Questions? Email marianne.e.casilio@vanderbilt.edu

% Note: Custom functions used include read_nifti, write_nifti, cluster_image
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd('/neuroling/projects/neuroaprocsa/data_sharing'); % change as needed

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Voxelwise analyses (see main text and Figs. 4 & 5 for details), which
% require downloading vlsm2 at https://langneurosci.org/resources/vlsm

% Note: This code is provided to show model specifications only; it will 
% not run as the individual lesion masks are not provided. These masks will 
% be available at a future date as part of a larger dataset at 
% http://langneurosci.org/recovery
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vlsm2('vlsm_design.txt', [],'paraphasia', 'vars', {'paraphasia', 'LesionSize'}, ...
    'maskthresh', 6, 'highscoresarebad', true, 'nperms', 10000)
vlsm2('vlsm_design.txt', [], 'logopenia', 'vars', {'logopenia', 'LesionSize'}, ... 
    'maskthresh', 6, 'highscoresarebad', true, 'nperms', 10000)
vlsm2('vlsm_design.txt', [], 'agrammatism', 'vars', {'agrammatism', 'LesionSize'}, ... 
    'maskthresh', 6, 'highscoresarebad', true, 'nperms', 10000)
vlsm2('vlsm_design.txt', [], 'motorspeech', 'vars', {'motorspeech', 'LesionSize'}, ... 
    'maskthresh', 6, 'highscoresarebad', true, 'nperms', 10000)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data preparation for subsequent analyses with permutation-corrected maps 
% derived from the voxelwise analyses shown above
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load data
[hdr1, para] = read_nifti('paraphasia_t_0.01_thresh.nii');
[hdr2, logo] = read_nifti('logopenia_t_0.01_thresh.nii');
[hdr3, agram] = read_nifti('agrammatism_t_0.01_thresh.nii');
[hdr4, motor] = read_nifti('motorspeech_t_0.01_thresh.nii');

% Create and write vectors for calculating Dice-Sorensen Coefficients in R
writematrix(para(:), 'para_vector.txt')
writematrix(logo(:), 'logo_vector.txt')
writematrix(agram(:), 'agram_vector.txt')
writematrix(motor(:), 'motor_vector.txt')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pairwise spatial overlap maps (see Supplementary Fig. 2A for details)

% Note: 2.36 is the critical t-statistic at voxelwise p < .01 for all maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Paraphasia-Logopenia
para_logo_assoc = (para >= 2.36) & (logo >= 2.36);
para_logo_disassoc = ((para >= 2.36) & ~para_logo_assoc) | ((logo >= 2.36) & ~para_logo_assoc);

write_nifti(hdr1, para_logo_assoc,'para_logo_assoc.nii.gz')
write_nifti(hdr1, para_logo_disassoc,'para_logo_img_disassoc.nii.gz')

% Paraphasia-Agrammatism
para_agram_assoc = (para >= 2.36) & (agram >= 2.36);
para_agram_disassoc = ((para >= 2.36) & ~para_agram_assoc) | ((agram >= 2.36) & ~para_agram_assoc);

write_nifti(hdr1, para_agram_assoc,'para_agram_img_assoc.nii.gz')
write_nifti(hdr1, para_agram_disassoc,'para_agram_img_disassoc.nii.gz')

% Paraphasia-Motor speech
para_motor_assoc = (para >= 2.36) & (motor >= 2.36);
para_motor_disassoc = ((para >= 2.36) & ~para_motor_assoc) | ((motor >= 2.36) & ~para_motor_assoc);

write_nifti(hdr1, para_motor_assoc,'para_motor_img_assoc.nii.gz')
write_nifti(hdr1, para_motor_disassoc,'para_motor_img_disassoc.nii.gz')

% Logopenia-Agrammatism
logo_agram_assoc = (logo >= 2.36) & (agram >= 2.36);
logo_agram_disassoc = ((logo >= 2.36) & ~logo_agram_assoc) | ((agram >= 2.36) & ~logo_agram_assoc);

write_nifti(hdr1, logo_agram_assoc,'logo_agram_img_assoc.nii.gz')
write_nifti(hdr1, logo_agram_disassoc,'logo_agram_img_disassoc.nii.gz')

% Logopenia-Motor speech
logo_motor_assoc = (logo >= 2.36) & (motor >= 2.36);
logo_motor_disassoc = ((logo >= 2.36) & ~logo_motor_assoc) | ((motor >= 2.36) & ~logo_motor_assoc);

write_nifti(hdr1, logo_motor_assoc,'/home/marianne.casilio/Desktop/logo_motor_img_assoc.nii.gz')
write_nifti(hdr1, logo_motor_disassoc,'/home/marianne.casilio/Desktop/logo_motor_img_disassoc.nii.gz')

% Agrammatism-Motor speech
motor_agram_assoc = (motor >= 2.36) & (agram >= 2.36);
motor_agram_disassoc = ((motor >= 2.36) & ~motor_agram_assoc) | ((agram >= 2.36) & ~motor_agram_assoc);

write_nifti(hdr1, motor_agram_assoc,'motor_agram_img_assoc.nii.gz')
write_nifti(hdr1, motor_agram_disassoc,'motor_agram_img_disassoc.nii.gz')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Spatial overlap four all four maps combined (see Supplementary Fig. 2B for details)

% Note: 2.36 is the critical t-statistic at voxelwise p < .01 for all maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

all_assoc = (para >= 2.36) & (logo >= 2.36) & (agram >= 2.36) & (motor >= 2.36);
all_disassoc = ((para >= 2.36) & ~all_assoc) | ((logo >= 2.36) & ~all_assoc) | ...
     ((agram >= 2.36) & ~all_assoc) | ((motor >= 2.36) & ~all_assoc);

write_nifti(hdr1, all_assoc, 'all_assoc.nii.gz')
write_nifti(hdr1, all_disassoc, 'all_disassoc.nii.gz')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bias map: Paraphasia-Logopenia (see Fig. 6A for details)

% Note: 2.36 is the critical t-statistic at voxelwise p < .01 for all maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Re-scale Paraphasia and Logopenia maps to 0-100
para(isnan(para)) = 0;
vthrn = 2.36;
para_clust = cluster_image({hdr1, para, ''}, vthrn, 0, 2000); 
para_clust_ = para_clust(:);
para_ = para(:);
paravox = find(para_clust_ ~= 0);
parat = para_(paravox);
[~, paraind] = sort(parat);
para_clust_(paravox(paraind)) = (1:length(paravox)) / length(paravox) * 100;
para_clust_ = reshape(para_clust_, size(para_clust));

logo(isnan(logo)) = 0;
vthrn = 2.36;
logo_clust = cluster_image({hdr1, logo, ''}, vthrn, 0, 2000); % cluster_image() = custom function
logo_clust_ = logo_clust(:);
logo_ = logo(:);
logovox = find(logo_clust_ ~= 0);
logot = logo_(logovox);
[~, logoind] = sort(logot);
logo_clust_(logovox(logoind)) = (1:length(logovox)) / length(logovox) * 100;
logo_clust_ = reshape(logo_clust_, size(logo_clust));

% Write intermediate files if desired
write_nifti(hdr1, para_clust_, 'para_rescaled.nii.gz');
write_nifti(hdr1, logo_clust_, 'logo_rescaled.nii.gz');

% Create bias map constrained to pairwise spatial overlap
bias_pl = para_clust_ - logo_clust_;
bias_pl_constrained = bias_pl .* (para_logo_assoc == 1);
bias_pl_positive = bias_pl_constrained .* (bias_pl_constrained > 0); % Paraphasia > Logopenia
bias_pl_negative = bias_pl_constrained .* (bias_pl_constrained < 0); % Logopenia > Paraphasia

write_nifti(hdr1, bias_pl_positive, 'bias_paralogo_positive.nii.gz')
write_nifti(hdr1, bias_pl_negative, 'bias_paralogo_negative.nii.gz')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bias map: Logopenia-Agrammatism (see Fig. 6B for details)

% Note: 2.36 is the critical t-statistic at voxelwise p < .01 for all maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Re-scale Logopenia and Agrammatism maps to 0-100
logo(isnan(logo)) = 0;
vthrn = 2.36;
logo_clust = cluster_image({hdr1, logo, ''}, vthrn, 0, 2000); % cluster_image() = custom function
logo_clust_ = logo_clust(:);
logo_ = logo(:);
logovox = find(logo_clust_ ~= 0);
logot = logo_(logovox);
[~, logoind] = sort(logot);
logo_clust_(logovox(logoind)) = (1:length(logovox)) / length(logovox) * 100;
logo_clust_ = reshape(logo_clust_, size(logo_clust));

agram(isnan(agram)) = 0;
vthrn = 2.36;
agram_clust = cluster_image({hdr1, agram, ''}, vthrn, 0, 2000); 
agram_clust_ = agram_clust(:);
agram_ = agram(:);
agramvox = find(agram_clust_ ~= 0);
agramt = agram_(agramvox);
[~, agramind] = sort(agramt);
agram_clust_(agramvox(agramind)) = (1:length(agramvox)) / length(agramvox) * 100;
agram_clust_ = reshape(agram_clust_, size(agram_clust));

% Write intermediate files if desired
write_nifti(hdr1, logo_clust_, 'logo_rescaled.nii.gz');
write_nifti(hdr1, agram_clust_, 'agram_rescaled.nii.gz');

% Create bias map constrained to pairwise spatial overlap
bias_la = logo_clust_ - agram_clust_;
bias_la_constrained = bias_la .* (logo_agram_assoc == 1);
bias_la_positive = bias_la_constrained .* (bias_la_constrained > 0); % Paraphasia > Logopenia
bias_la_negative = bias_la_constrained .* (bias_la_constrained < 0); % Logopenia > Paraphasia

write_nifti(hdr1, bias_la_positive, 'bias_logoagram_positive.nii.gz')
write_nifti(hdr1, bias_la_negative, 'bias_logoagram_negative.nii.gz')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bias map: Agrammatism-Motor speech (see Fig. 6C for details)

% Note: 2.36 is the critical t-statistic at voxelwise p < .01 for all maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Re-scale Agrammatism and Motor speech maps to 0-100
agram(isnan(agram)) = 0;
vthrn = 2.36;
agram_clust = cluster_image({hdr1, agram, ''}, vthrn, 0, 2000); 
agram_clust_ = agram_clust(:);
agram_ = agram(:);
agramvox = find(agram_clust_ ~= 0);
agramt = agram_(agramvox);
[~, agramind] = sort(agramt);
agram_clust_(agramvox(agramind)) = (1:length(agramvox)) / length(agramvox) * 100;
agram_clust_ = reshape(agram_clust_, size(agram_clust));

motor(isnan(motor)) = 0;
vthrn = 2.36;
motor_clust = cluster_image({hdr1, motor, ''}, vthrn, 0, 2000); 
motor_clust_ = motor_clust(:);
motor_ = motor(:);
motorvox = find(motor_clust_ ~= 0);
motort = logo_(motorvox);
[~, motorind] = sort(motort);
motor_clust_(motorvox(motorind)) = (1:length(motorvox)) / length(motorvox) * 100;
motor_clust_ = reshape(motor_clust_, size(motor_clust));

% Write intermediate files if desired
write_nifti(hdr1, agram_clust_, 'agram_rescaled.nii.gz');
write_nifti(hdr1, motor_clust_, 'motor_rescaled.nii.gz');

% Create bias map constrained to pairwise spatial overlap
bias_am = agram_clust_ - motor_clust_;
bias_am_constrained = bias_am .* (agram_motor_assoc == 1);
bias_am_positive = bias_am_constrained .* (bias_am_constrained > 0); % Agrammatism > Motor speech
bias_am_negative = bias_am_constrained .* (bias_am_constrained < 0); % Motor speech > Agrammatism

write_nifti(hdr1, bias_am_positive, 'bias_agrammotor_positive.nii.gz')
write_nifti(hdr1, bias_am_negative, 'bias_agrammotor_negative.nii.gz')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Maps of the brain-behavior model (see Fig. 6D for details)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Paraphasia
para_only = (para >= 2.36) & ~((logo >= 2.36) | (agram >= 2.36) | (motor >= 2.36));
para_only_100 = (para_only == 1) * 100;
para_only_with_bias = para_only_100 + bias_pl_positive;

write_nifti(hdr1, para_only_with_bias, 'para_only_with_bias.nii.gz')

% Logopenia
% Note: Fig. legend expressed on positive scale for continuity
logo_only = (logo >= 2.36) & ~((para >= 2.36) | (agram >= 2.36) | (motor >= 2.36));
logo_only_100 = (logo_only == 1) * -100;
bias_logo_avg = (bias_pl_negative + (bias_la_positive * -1))/2;
logo_only_with_bias = logo_only_100 + bias_logo_avg;

write_nifti(hdr1, logo_only_with_bias, 'logo_only_with_bias.nii.gz')

% Agrammatism
agram_only = (agram >= 2.36) & ~((para >= 2.36) | (logo >= 2.36) | (motor >= 2.36));
agram_only_100 = (agram_only == 1) * 100;
bias_agram_avg = (bias_am_positive + (bias_la_negative * -1))/2;
agram_only_with_bias = agram_only_100 + bias_agram_avg;

write_nifti(hdr1, agram_only_with_bias, 'agram_only_with_bias.nii.gz')

% Motor speech
% Note: Fig. legend expressed on positive scale for continuity
motor_only = (motor >= 2.36) & ~((para >= 2.36) | (logo >= 2.36) | (agram >= 2.36));
motor_only_100 = (motor_only == 1) * -100;
motor_only_with_bias = motor_only_100 + bias_am_negative;

write_nifti(hdr1, motor_only_with_bias, 'motor_only_with_bias.nii.gz')