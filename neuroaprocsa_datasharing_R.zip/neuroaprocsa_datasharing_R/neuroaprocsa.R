################################################################################
# Code for reproducing analyses in Casilio et al., "Four dimensions of
# naturalistic language production in aphasia after stroke"

# Last updated by Marianne Casilio on 9/22/2023
# Questions? Email marianne.e.casilio@vanderbilt.edu
################################################################################

setwd("~/Desktop/neuroaprocsa_submission/data_sharing/data_sharing_R") # change if needed

# Install packages if needed
install.packages('psych')
install.packages('psych')
install.packages('irr')
install.packages('polycor')
install.packages('boot')
install.packages('jtools')

################################################################################
# Exploratory factor analysis with oblique rotation on 
# Casilio et al., 2019 dataset (see Supplementary Table 1 for details)
################################################################################

# Prepare data and attach packages
orig_dataset = read.table("aprocsa_2019.txt") 
colnames(orig_dataset) = c("anomia","abandoned_utterances","empty_speech","semantic_paraphasias",
                  "phonemic_paraphasias","neologisms","jargon","perseverations",
                  "stereotypies_and_automatisms","short_and_simplified_utterances",
                  "omission_of_bound_morphemes","omission_of_function_words",
                  "paragrammatism","pauses_between_utterances","pauses_within_utterances",
                  "halting_and_effortful","reduced_speech_rate","retracing","false_starts",
                  "target_unclear","meaning_unclear","apraxia_of_speech","expressive_aphasia")
rownames(orig_dataset) = c("fridriksson05a","TAP18a","whiteside06a","adler01a","kurland07a",
                  "kurland28a","scale30a","ACWT09a","wright203a","williamson04a",
                  "kurland20a","TCU07a","williamson16a","ACWT02a","elman12a","elman14a",
                  "thompson05a","kurland18a","scale33a","TCU08a","TAP11a","BU08a","TAP09a",
                  "scale09a")

library(psych)

# Exploratory factor analysis with oblimin rotation
fa(orig_dataset,4, fm="ml", rotate = "oblimin") 

################################################################################
# Inter-rater agreement (see main text for details)
################################################################################

# Prepare data and attach packages
features_dimensions = read.table("neuroaprocsa_features_dimensions.txt",
                                 header = TRUE)
head(features_dimensions)

features_mckbks_agree = cbind(features_dimensions$rating_kb,
                              features_dimensions$rating_mc,
                              features_dimensions$rating_ks)

library(irr)
library(boot)

# Inter-rater agreement between MC and KB
boot_function_mckb = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_mckb = boot(features_mckbks_agree, boot_function_iccs, 10000) 
boot_mckb # original = intra-class correlation coefficient
boot.ci(boot.out = boot_mckb,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Inter-rater agreement between MC and KS
boot_function_mcks = function(data,x)
{
  df = data[x,]
  c(icc(df[,2:3], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_mcks = boot(features_mckbks_agree, boot_function_mcks, 10000) 
boot_mcks # original = intra-class correlation coefficient
boot.ci(boot.out = boot_mcks,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

################################################################################
# Features-dimension polyserial correlations (see Supplementary Fig. 1 for details)
################################################################################

# Load/prepare data and attach packages
features_dimensions = read.table("neuroaprocsa_features_dimensions.txt",
                                 header = TRUE) # if not loaded above
head(features_dimensions) 

features_dimensions$feature = as.factor(features_dimensions$feature)

paraphasia_correlations = features_dimensions [features_dimensions$feature %in%
                                                 c("abandoned", "empty",
                                                   "falsestarts", "jargon",
                                                   "meaning_unclear", "neologisms",
                                                   "paragram", "phon_para","sempara"),]

paraphasia =data.frame(paraphasia_correlations$paraphasia, 
                        paraphasia_correlations$rating_mc, 
                        as.factor(as.numeric(paraphasia_correlations$feature)))

logopenia_correlations = features_dimensions [features_dimensions$feature %in%
                                                 c("anomia", "abandoned", 
                                                   "expressive_aphasia",
                                                   "meaning_unclear",
                                                   "pauses_between", "pauses_within",
                                                   "persev", "reducedrate"),]

logopenia = data.frame(logopenia_correlations$logopenia, 
                        logopenia_correlations$rating_mc, 
                        as.factor(as.numeric(logopenia_correlations$feature)))

agrammatism_correlations = features_dimensions [features_dimensions$feature %in%
                                                c("expressive_aphasia", 
                                                  "meaning_unclear", "omiss_bound",
                                                  "omiss_function", "retracing",
                                                  "shortsimple", "stereotypies"),]

agrammatism = data.frame(agrammatism_correlations$agrammatism, 
                        agrammatism_correlations$rating_mc, 
                        as.factor(as.numeric(agrammatism_correlations$feature)))

motorspeech_correlations = features_dimensions [features_dimensions$feature %in%
                                                c("apraxia", "halting",
                                                  "pauses_between", "reducedrate",
                                                  "distortartic"),]

motorspeech = data.frame(motorspeech_correlations$motorspeech, 
                         motorspeech_correlations$rating_mc, 
                         as.factor(as.numeric(motorspeech_correlations$feature)))

# Polyserial correlations with bootstrapped 95% confidence intervals
library(polycor) # continuous Y and discrete X
library(boot) # if not loaded above

boot_function_parapoly = function(data,x)
{
  df = data[x,]
c(sapply(
  split(data.frame(df[,1], df[,2]), df[,3]), 
  function(x) polyserial(x[[1]],x[[2]])))
} 
set.seed(42)
boot_parapoly = boot(paraphasia, boot_function_parapoly, 10000) 
head(boot_parapoly$t)
boot_parapoly # polyserial correlations
boot.ci(boot.out = boot_parapoly,
        type = c("bca"))
lapply(1:dim(boot_parapoly$t)[2], 
       function (i) 
         boot.ci(
           boot_parapoly, 
           type = "bca", 
           index = i)
       ) # BCa = bootstrapped 95% confidence intervals

boot_function_logopoly = function(data,x)
{
  df = data[x,]
  c(sapply(
    split(data.frame(df[,1], df[,2]), df[,3]), 
    function(x) polyserial(x[[1]],x[[2]])))
} 
set.seed(42)
boot_logopoly = boot(logopenia, boot_function_logopoly, 10000) 
head(boot_logopoly$t)
boot_logopoly # polyserial correlations
boot.ci(boot.out = boot_logopoly,
        type = c("bca"))
lapply(1:dim(boot_logopoly$t)[2], 
       function (i) 
         boot.ci(
           boot_logopoly, 
           type = "bca", 
           index = i)
) # BCa = bootstrapped 95% confidence intervals

boot_function_agrampoly = function(data,x)
{
  df = data[x,]
  c(sapply(
    split(data.frame(df[,1], df[,2]), df[,3]), 
    function(x) polyserial(x[[1]],x[[2]])))
} 
set.seed(42)
boot_agrampoly = boot(agrammatism, boot_function_agrampoly, 10000) 
head(boot_agrampoly$t)
boot_agrampoly # polyserial correlations
boot.ci(boot.out = boot_agrampoly,
        type = c("bca"))
lapply(1:dim(boot_agrampoly$t)[2], 
       function (i) 
         boot.ci(
           boot_agrampoly, 
           type = "bca", 
           index = i)
) # BCa = bootstrapped 95% confidence intervals

boot_function_motorpoly = function(data,x)
{
  df = data[x,]
  c(sapply(
    split(data.frame(df[,1], df[,2]), df[,3]), 
    function(x) polyserial(x[[1]],x[[2]])))
} 
set.seed(42)
boot_motorpoly = boot(motorspeech, boot_function_motorpoly, 10000) 
head(boot_motorpoly$t)
boot_motorpoly # polyserial correlations
boot.ci(boot.out = boot_motorpoly,
        type = c("bca"))
lapply(1:dim(boot_motorpoly$t)[2], 
       function (i) 
         boot.ci(
           boot_motorpoly, 
           type = "bca", 
           index = i)
) # BCa = bootstrapped 95% confidence intervals

################################################################################
# Internal consistency of the APROCSA dimension scores (see main text for details)
################################################################################

# Prepare data and attach packages
paraphasia_ratings1 = reshape(paraphasia_correlations, 
                             idvar = "pid", timevar = "feature", direction = "wide")

paraphasia_ratings2 = data.frame(paraphasia_ratings1$rating_mc.meaning_unclear, 
                                         paraphasia_ratings1$rating_mc.abandoned, 
                                         paraphasia_ratings1$rating_mc.empty, 
                                         paraphasia_ratings1$rating_mc.sempara, 
                                         paraphasia_ratings1$rating_mc.falsestarts, 
                                         paraphasia_ratings1$rating_mc.phon_para, 
                                         paraphasia_ratings1$rating_mc.neologisms, 
                                         paraphasia_ratings1$rating_mc.jargon, 
                                         paraphasia_ratings1$rating_mc.paragram)

logopenia_ratings1 = reshape(logopenia_correlations, 
                              idvar = "pid", timevar = "feature", direction = "wide")

logopenia_ratings2 = data.frame(logopenia_ratings1$rating_mc.abandoned, 
                           logopenia_ratings1$rating_mc.persev, 
                           logopenia_ratings1$rating_mc.meaning_unclear, 
                           logopenia_ratings1$rating_mc.anomia, 
                           logopenia_ratings1$rating_mc.expressive_aphasia, 
                           logopenia_ratings1$rating_mc.pauses_between, 
                           logopenia_ratings1$rating_mc.pauses_within, 
                           logopenia_ratings1$rating_mc.reducedrate)

agrammatism_ratings1 = reshape(agrammatism_correlations, 
                             idvar = "pid", timevar = "feature", direction = "wide")

agrammatism_ratings2 = data.frame(agrammatism_ratings1$rating_mc.expressive_aphasia, 
                    agrammatism_ratings1$rating_mc.meaning_unclear, 
                    agrammatism_ratings1$rating_mc.shortsimple,
                    agrammatism_ratings1$rating_mc.omiss_bound, 
                    agrammatism_ratings1$rating_mc.omiss_function, 
                    agrammatism_ratings1$rating_mc.retracing, 
                    agrammatism_ratings1$rating_mc.stereotypies)

motorspeech_ratings1 = reshape(motorspeech_correlations, 
                               idvar = "pid", timevar = "feature", direction = "wide")

motorspeech_ratings2 = cbind(motorspeech_ratings1$rating_mc.apraxia, 
                    motorspeech_ratings1$rating_mc.distortartic, 
                    motorspeech_ratings1$rating_mc.halting, 
                    motorspeech_ratings1$rating_mc.pauses_between, 
                    motorspeech_ratings1$rating_mc.reducedrate)

library(psych)

# MacDonald's wt coefficients
omega(paraphasia_ratings2)
omega(logopenia_ratings2)
omega(agrammatism_ratings2)
omega(motorspeech_ratings2)

################################################################################
# ROI analyses (see Fig. 2, Table 2, and Supplementary Table 2 for details)

# Note: The combined ROI map used to create the ROIs from the individual lesion masks
# is provided in the data_sharing_matlab zip file (neuroaprocsa_rois.nii.gz). 
# The individual lesion masks associated with the larger study will be provided 
# at a future date at https://langneurosci.org/recovery/portal
################################################################################

# Prepare data and load packages
dimensions_rois = read.table('neuroaprocsa_dimensions_rois.txt', header = TRUE)
head(dimensions_rois)

library(jtools)

# Univariate models and results
para = lm(data = dimensions_rois, paraphasia ~ prefrontalROI + 
            frontoparietalROI + temporalROI + otherROI)
summary(para)
summ(para, part.corr = TRUE, digits = 3) 

logo = lm(data = dimensions_rois, logopenia ~ prefrontalROI + 
            frontoparietalROI + temporalROI + otherROI)
summary(logo)
summ(logo, part.corr = TRUE, digits = 3)

agram = lm(data = dimensions_rois, agrammatism ~ prefrontalROI + 
             frontoparietalROI + temporalROI + otherROI)
summary(agram)
summ(agram, part.corr = TRUE, digits = 3)

motor = lm(data = dimensions_rois, motorspeech ~ prefrontalROI + 
             frontoparietalROI + temporalROI + otherROI)
summary(motor)
summ(motor, part.corr = TRUE, digits = 3)

# Multivariate model and results
all = lm(data = dimensions_rois, cbind(paraphasia, logopenia, agrammatism, motorspeech) ~ 
           prefrontalROI + frontoparietalROI + temporalROI + otherROI)
summary(all) # Identical to univariate results
anova(all) # Pillai's trace and F-test

################################################################################
# Dice-Sorensen Coefficients (see Supplementary Fig. 2 for details)

# Note: The vectors can be derived from data/code in neuroaprocsa.m in the
# neuroaprocsa_datasharing_matlab zip file but are also provided in the
# neuroaprocsa_datasharing_R zip file
################################################################################

# Load data and packages
para_vector = read.table("para_vector.txt", header = FALSE)
colnames(para_vector) = c("para")
logo_vector = read.table("logo_vector.txt", header = FALSE)
colnames(logo_vector) = c("logo")
agram_vector = read.table("agram_vector.txt", header = FALSE)
colnames(agram_vector) = c("agram")
motor_vector = read.table("motor_vector.txt", header = FALSE)
colnames(motor_vector) = c("motor")

library(boot)

# Paraphasia-Logopenia DSC with bootstrapped 95% confidence intervals
para_vector = read.table("para_vector.txt", header = FALSE)
colnames(para_vector) = c("para")
logo_vector = read.table("logo_vector.txt", header = FALSE)
colnames(logo_vector) = c("logo")

para_vector[para_vector == 0 & logo_vector == 0] = NA
logo_vector[logo_vector == 0 & is.na(para_vector)] = NA
para_vector[para_vector > 0] = 1
logo_vector[logo_vector > 0] = 1
para_vector[para_vector == 0] = 0
logo_vector[logo_vector == 0] = 0
para_vector = na.omit(para_vector)
logo_vector = na.omit(logo_vector)

paralogo = cbind(para_vector, logo_vector)

paralogo_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
paralogo_bootstrap = boot(paralogo, paralogo_function, R = 10000)
paralogo_bootstrap # DSC coefficient
boot.ci(boot.out = paralogo_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals

# Paraphasia-Agrammatism DSC with bootstrapped 95% confidence intervals
para_vector = read.table("para_vector.txt", header = FALSE)
colnames(para_vector) = c("para")
agram_vector = read.table("agram_vector.txt", header = FALSE)
colnames(agram_vector) = c("agram")

para_vector[para_vector == 0 & agram_vector == 0] = NA
agram_vector[agram_vector == 0 & is.na(para_vector)] = NA
para_vector[para_vector > 0] = 1
agram_vector[agram_vector > 0] = 1
para_vector[para_vector == 0] = 0
agram_vector[agram_vector == 0] = 0
para_vector = na.omit(para_vector)
agram_vector = na.omit(agram_vector)

paraagram = cbind(para_vector, agram_vector)

paraagram_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
paraagram_bootstrap = boot(paraagram, paraagram_function, R = 10000)
paraagram_bootstrap # DSC coefficient
boot.ci(boot.out = paraagram_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals

# Paraphasia-Motor speech DSC with bootstrapped 95% confidence intervals
para_vector = read.table("para_vector.txt", header = FALSE)
colnames(para_vector) = c("para")
motor_vector = read.table("motor_vector.txt", header = FALSE)
colnames(motor_vector) = c("motor")

para_vector[para_vector == 0 & motor_vector == 0] = NA
motor_vector[motor_vector == 0 & is.na(para_vector)] = NA
para_vector[para_vector > 0] = 1
motor_vector[motor_vector > 0] = 1
para_vector[para_vector == 0] = 0
motor_vector[motor_vector == 0] = 0
para_vector = na.omit(para_vector)
motor_vector = na.omit(motor_vector)

paramotor = cbind(para_vector, motor_vector)

paramotor_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
paramotor_bootstrap = boot(paramotor, paramotor_function, R = 10000)
paramotor_bootstrap # DSC coefficient
boot.ci(boot.out = paramotor_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals

# Logopenia-Agrammatism DSC with bootstrapped 95% confidence intervals
logo_vector = read.table("logo_vector.txt", header = FALSE)
colnames(logo_vector) = c("logo")
agram_vector = read.table("agram_vector.txt", header = FALSE)
colnames(agram_vector) = c("agram")

logo_vector[logo_vector == 0 & agram_vector == 0] = NA
agram_vector[agram_vector == 0 & is.na(logo_vector)] = NA
logo_vector[logo_vector > 0] = 1
agram_vector[agram_vector > 0] = 1
logo_vector[logo_vector == 0] = 0
agram_vector[agram_vector == 0] = 0
logo_vector = na.omit(logo_vector)
agram_vector = na.omit(agram_vector)

logoagram = cbind(logo_vector, agram_vector)

logoagram_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
logoagram_bootstrap = boot(logoagram, logoagram_function, R = 10000)
logoagram_bootstrap # DSC coefficient
boot.ci(boot.out = logoagram_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals

# Logopenia-Motor speech DSC with bootstrapped 95% confidence intervals
logo_vector = read.table("logo_vector.txt", header = FALSE)
colnames(para_vector) = c("logo")
motor_vector = read.table("motor_vector.txt", header = FALSE)
colnames(motor_vector) = c("motor")

logo_vector[logo_vector == 0 & motor_vector == 0] = NA
motor_vector[motor_vector == 0 & is.na(logo_vector)] = NA
logo_vector[logo_vector > 0] = 1
motor_vector[motor_vector > 0] = 1
logo_vector[logo_vector == 0] = 0
motor_vector[motor_vector == 0] = 0
logo_vector = na.omit(logo_vector)
motor_vector = na.omit(motor_vector)

logomotor = cbind(logo_vector, motor_vector)

logomotor_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
logomotor_bootstrap = boot(logomotor, logomotor_function, R = 10000)
logomotor_bootstrap # DSC coefficient
boot.ci(boot.out = logomotor_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals

# Agrammatism-Motor speech DSC with bootstrapped 95% confidence intervals
agram_vector = read.table("agram_vector.txt", header = FALSE)
colnames(agram_vector) = c("agram")
motor_vector = read.table("motor_vector.txt", header = FALSE)
colnames(motor_vector) = c("motor")

agram_vector[agram_vector == 0 & motor_vector == 0] = NA
motor_vector[motor_vector == 0 & is.na(agram_vector)] = NA
agram_vector[agram_vector > 0] = 1
motor_vector[motor_vector > 0] = 1
agram_vector[agram_vector == 0] = 0
motor_vector[motor_vector == 0] = 0
agram_vector = na.omit(agram_vector)
motor_vector = na.omit(motor_vector)

agrammotor = cbind(agram_vector, motor_vector)

agrammotor_function = function(data, x)
{
  df = data[x,]
  c(2 * (sum(df[,1] & df[,2])) / (sum(df[,1]) + sum(df[,2]))) # DSC formula
}
set.seed(42)
agrammotor_bootstrap = boot(agrammotor, agrammotor_function, R = 10000)
agrammotor_bootstrap # DSC coefficient
boot.ci(boot.out = agrammotor_bootstrap,
        type = c("bca")) # bootstrapped 95% confidence intervals